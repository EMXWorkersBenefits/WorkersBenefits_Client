import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-picture-grid',
  templateUrl: './picture-grid.component.html',
  styleUrls: ['./picture-grid.component.css']
})
export class PictureGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
