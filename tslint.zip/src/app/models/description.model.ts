export class Description {
  public title: string;
  public details: string;
  public price: number;
  constructor(title: string, details: string, price: number) {
    this.title = title;
    this.details = details;
    this.price = price;
  }
}
